﻿using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.CommonModels;
using Xunit;

namespace ExamTest
{
    [Binding]
    public class SpecFlowFeature1Steps
    {
        double num;
        double res;
        [Given(@"the number is Pi")]
        public void GivenTheNumberIsPi()
        {
            num = Math.PI;
        }
        
        [When(@"the sinus of number")]
        public void WhenTheSinusOfNumber()
        {
            res = Math.Sin(num);
            
        }
        
        [When(@"the cosinus of number")]
        public void WhenTheCosinusOfNumber()
        {
            res = Math.Cos(num);

        }

        [When(@"the tangens of number")]
        public void WhenTheTangensOfNumber()
        {
            res = Math.Tan(num);
        }
        
        [Then(@"the result should be (.*)")]
        public void ThenTheResultShouldBe(int result)
        {
            var expected = result;
            var actual = res;
            Assert.Equal(expected, actual, 5);
        }
    }
}
